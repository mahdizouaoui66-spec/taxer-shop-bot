const {
  section, isExempt, logSecurity, timeoutMember, tempReply, securityEmbed,
} = require('../utils/security.js');

// Anti-spam, anti-mentions en masse et anti-liens d'invitation Discord.
// Les admins, le staff et l'owner ne sont jamais touchés.

const INVITE_RE = /(discord\.gg|discord(?:app)?\.com\/invite)\/[a-z0-9-]+/i;
const spamMap = new Map(); // userId -> [{ ts, msg }]

// Nettoyage régulier pour ne pas garder des messages en mémoire
setInterval(() => {
  const now = Date.now();
  for (const [id, list] of spamMap) {
    const fresh = list.filter(m => now - m.ts < 30000);
    if (fresh.length) spamMap.set(id, fresh); else spamMap.delete(id);
  }
}, 60000).unref();

async function punish(message, member, minutes, title, reason) {
  const done = await timeoutMember(member, minutes, reason);
  await tempReply(
    message.channel,
    `🚫 <@${member.id}> ${reason}${done ? ` — تم كتمه ${minutes} دقيقة.` : ''}`
  );
  await logSecurity(
    message.guild,
    securityEmbed(title, `**العضو:** <@${member.id}> (${member.user.tag})\n**القناة:** <#${message.channel.id}>\n**السبب:** ${reason}\n**الإجراء:** ${done ? `كتم ${minutes} دقيقة` : 'حذف الرسائل فقط (لا أملك الصلاحية للكتم)'}`, '#e67e22')
  );
}

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (!message.guild || message.author.bot || message.webhookId) return;

    const member = message.member || await message.guild.members.fetch(message.author.id).catch(() => null);
    if (!member || isExempt(member)) return;

    // ── Mentions en masse ──
    const mentionsCfg = section('antiMentions');
    if (mentionsCfg.enabled) {
      const total = message.mentions.users.size + message.mentions.roles.size;
      if (total >= mentionsCfg.maxMentions) {
        await message.delete().catch(() => {});
        await punish(message, member, mentionsCfg.timeoutMinutes,
          '🚨 منشن جماعي', 'ممنوع عمل منشن لعدد كبير من الأعضاء!');
        return;
      }
    }

    // ── Liens d'invitation Discord ──
    const invitesCfg = section('antiInvites');
    if (invitesCfg.enabled && INVITE_RE.test(message.content)) {
      await message.delete().catch(() => {});
      await tempReply(message.channel, `🚫 <@${member.id}> ممنوع نشر روابط سيرفرات أخرى هنا!`);
      await logSecurity(
        message.guild,
        securityEmbed('🔗 رابط دعوة محذوف', `**العضو:** <@${member.id}> (${member.user.tag})\n**القناة:** <#${message.channel.id}>`, '#e67e22')
      );
      return;
    }

    // ── Spam (trop de messages en peu de temps) ──
    const spamCfg = section('antiSpam');
    if (spamCfg.enabled) {
      const now = Date.now();
      const list = (spamMap.get(member.id) || []).filter(m => now - m.ts < spamCfg.perSeconds * 1000);
      list.push({ ts: now, msg: message });
      spamMap.set(member.id, list);

      if (list.length >= spamCfg.maxMessages) {
        spamMap.delete(member.id);
        for (const m of list) m.msg.delete().catch(() => {});
        await punish(message, member, spamCfg.timeoutMinutes,
          '🚨 سبام', 'ممنوع السبام!');
      }
    }
  },
};
