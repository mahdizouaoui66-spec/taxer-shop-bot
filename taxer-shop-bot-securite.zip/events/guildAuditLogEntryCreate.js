const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AuditLogEvent
} = require('discord.js');
const config = require('../config.json');
const { section } = require('../utils/security.js');

const OWNER_ID       = '1113897921922994337';
const CO_OWNER_ROLE  = '1385261115524644894';
const ADMIN_ROLE_IDS = config.tickets.adminRoleIds || [];

const counters = new Map();

function incrementCounter(userId, type) {
  const key = `${userId}_${type}`;
  if (!counters.has(key)) counters.set(key, { count: 0, timer: null });
  const c = counters.get(key);
  c.count++;
  if (c.timer) clearTimeout(c.timer);
  c.timer = setTimeout(() => counters.delete(key), 10000);
  return c.count;
}

function isProtected(member) {
  return member.id === OWNER_ID
      || member.roles.cache.has(CO_OWNER_ROLE);
}

// Retire immédiatement tous les rôles du membre (réversible : l'owner peut les remettre)
async function stripRoles(member) {
  try {
    const removable = member.roles.cache.filter(r => r.id !== member.guild.id && !r.managed && r.editable);
    if (!removable.size) return 0;
    await member.roles.remove(removable, 'Anti-nuke : action suspecte détectée');
    return removable.size;
  } catch (e) {
    console.error('Strip roles error:', e.message);
    return 0;
  }
}

async function alertOwner(client, guild, userId, reason, details, autoStrip = false) {
  try {
    const owner  = await client.users.fetch(OWNER_ID);
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;
    if (isProtected(member)) return;

    // Anti-nuke automatique : on retire les rôles tout de suite, sans attendre l'owner
    let stripped = 0;
    if (autoStrip && section('antiNuke').autoRemoveRoles) {
      stripped = await stripRoles(member);
      if (stripped) details += `\n\n🛡️ تم سحب **${stripped}** رتبة تلقائياً لحماية السيرفر.`;
    }

    const embed = new EmbedBuilder()
      .setColor('#cc0000')
      .setTitle('🚨 تحذير أمني — Taxer Shop')
      .setDescription(`**${reason}**`)
      .addFields(
        { name: '👤 العضو',    value: `${member.user.tag} (<@${userId}>)`, inline: true },
        { name: '🆔 ID',       value: userId,                              inline: true },
        { name: '📋 التفاصيل', value: details,                             inline: false },
      )
      .setThumbnail(member.user.displayAvatarURL())
      .setTimestamp()
      .setFooter({ text: 'Taxer Shop • اختر الإجراء المناسب' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`protect_removeroles_${userId}`)
        .setLabel('🟡 سحب الرتب')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`protect_kick_${userId}`)
        .setLabel('🟠 Kick')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`protect_ban_${userId}`)
        .setLabel('🔴 Ban')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`protect_ignore_${userId}`)
        .setLabel('⚪ تجاهل')
        .setStyle(ButtonStyle.Secondary),
    );

    await owner.send({ embeds: [embed], components: [row] });
  } catch(e) { console.error('Alert error:', e); }
}

module.exports = {
  name: 'guildAuditLogEntryCreate',
  async execute(auditLog, client) {
    const { action, executorId, targetId } = auditLog;
    const guild = auditLog.guild;
    if (!executorId) return;
    if (executorId === client.user.id) return;
    if (executorId === OWNER_ID) return;

    const executor = await guild.members.fetch(executorId).catch(() => null);
    if (!executor) return;
    if (isProtected(executor)) return;

    const nuke = section('antiNuke');
    if (!nuke.enabled) return;

    // Anti suppression de salons
    if (action === AuditLogEvent.ChannelDelete) {
      const count = incrementCounter(executorId, 'channelDelete');
      if (count >= nuke.channelDelete) {
        await alertOwner(client, guild, executorId,
          '⚠️ حذف مشبوه للقنوات!',
          `قام بحذف **${count}** قناة في أقل من 10 ثواني`,
          true
        );
      }
    }

    // Anti création massive de salons
    if (action === AuditLogEvent.ChannelCreate) {
      const count = incrementCounter(executorId, 'channelCreate');
      if (count >= nuke.channelCreate) {
        await alertOwner(client, guild, executorId,
          '⚠️ إنشاء مشبوه للقنوات!',
          `قام بإنشاء **${count}** قناة في أقل من 10 ثواني`,
          true
        );
      }
    }

    // Anti suppression de rôles
    if (action === AuditLogEvent.RoleDelete) {
      const count = incrementCounter(executorId, 'roleDelete');
      if (count >= nuke.roleDelete) {
        await alertOwner(client, guild, executorId,
          '⚠️ حذف مشبوه للرتب!',
          `قام بحذف **${count}** رتبة في أقل من 10 ثواني`,
          true
        );
      }
    }

    // Anti mass ban
    if (action === AuditLogEvent.MemberBanAdd) {
      const count = incrementCounter(executorId, 'massBan');
      if (count >= nuke.massBan) {
        await alertOwner(client, guild, executorId,
          '⚠️ حظر جماعي مشبوه!',
          `قام بحظر **${count}** عضو في أقل من 10 ثواني`,
          true
        );
      }
    }

    // Anti webhook (outil classique des attaques) : alerte seulement
    if (action === AuditLogEvent.WebhookCreate) {
      await alertOwner(client, guild, executorId,
        '🪝 تم إنشاء Webhook جديد!',
        'تم إنشاء webhook في السيرفر، تأكد أنك تعرف من أنشأه.'
      );
    }

    // Anti ajout de bot
    if (action === AuditLogEvent.BotAdd) {
      await alertOwner(client, guild, executorId,
        '🤖 تمت إضافة بوت جديد!',
        `أضاف بوت بـ ID: **${targetId}**`
      );
    }
  }
};
