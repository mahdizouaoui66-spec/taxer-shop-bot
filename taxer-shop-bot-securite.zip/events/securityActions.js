const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');
const { OWNER_ID } = require('../utils/security.js');

// Gère les boutons des alertes de sécurité envoyées en message privé à l'owner :
// 🟡 سحب الرتب / 🟠 Kick / 🔴 Ban / ⚪ تجاهل

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (!interaction.isButton() || !interaction.customId.startsWith('protect_')) return;

    if (interaction.user.id !== OWNER_ID) {
      return interaction.reply({ content: '❌ هذا الأمر للأونر فقط!', flags: 64 }).catch(() => {});
    }

    const [, action, userId] = interaction.customId.split('_');
    const guild = client.guilds.cache.get(config.server.guildId) || client.guilds.cache.first();
    if (!guild) return interaction.reply({ content: '❌ السيرفر غير موجود.', flags: 64 }).catch(() => {});

    let result;
    try {
      if (action === 'ignore') {
        result = '⚪ تم تجاهل التنبيه.';
      } else if (action === 'ban') {
        await guild.members.ban(userId, { reason: 'Alerte sécurité : décision de l\'owner' });
        result = '🔴 تم حظر العضو.';
      } else if (action === 'kick') {
        const member = await guild.members.fetch(userId);
        await member.kick('Alerte sécurité : décision de l\'owner');
        result = '🟠 تم طرد العضو.';
      } else if (action === 'removeroles') {
        const member = await guild.members.fetch(userId);
        const removable = member.roles.cache.filter(r => r.id !== guild.id && !r.managed && r.editable);
        await member.roles.remove(removable, 'Alerte sécurité : décision de l\'owner');
        result = `🟡 تم سحب ${removable.size} رتبة.`;
      } else {
        return;
      }
    } catch (e) {
      console.error('Protect action error:', e.message);
      result = `❌ فشل الإجراء : ${e.message}`;
    }

    const base = interaction.message.embeds[0]
      ? EmbedBuilder.from(interaction.message.embeds[0])
      : new EmbedBuilder().setTitle('🚨 تنبيه أمني');
    await interaction.update({
      embeds: [base.setFooter({ text: result })],
      components: [],
    }).catch(() => {});
  },
};
