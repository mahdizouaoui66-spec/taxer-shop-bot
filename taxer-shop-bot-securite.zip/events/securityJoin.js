const {
  section, logSecurity, dmOwner, securityEmbed,
} = require('../utils/security.js');

// Anti-raid : détecte beaucoup d'arrivées en peu de temps.
// Pendant un raid, les comptes trop récents sont expulsés automatiquement.

const recentJoins = []; // { member, ts }
let raidUntil = 0;

function accountAgeDays(member) {
  return (Date.now() - member.user.createdTimestamp) / 86400000;
}

async function kickYoung(member, reason) {
  try {
    await member.send('تم طردك مؤقتاً من **Taxer Shop** لأن حسابك جديد جداً وقت حدوث هجوم على السيرفر. يمكنك العودة لاحقاً.').catch(() => {});
    if (!member.kickable) return false;
    await member.kick(reason);
    return true;
  } catch (e) {
    console.error('Raid kick error:', e.message);
    return false;
  }
}

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const cfg = section('antiRaid');
    if (!cfg.enabled || member.user.bot) return;

    const now = Date.now();
    while (recentJoins.length && now - recentJoins[0].ts > cfg.perSeconds * 1000) recentJoins.shift();
    recentJoins.push({ member, ts: now });

    // Raid déjà en cours : on expulse les comptes récents
    if (now < raidUntil) {
      if (accountAgeDays(member) < cfg.minAccountAgeDays) {
        await kickYoung(member, 'Anti-raid : compte trop récent pendant un raid');
      }
      return;
    }

    // Raid détecté
    if (recentJoins.length >= cfg.joins) {
      raidUntil = now + cfg.raidModeMinutes * 60 * 1000;

      let kicked = 0;
      for (const j of recentJoins) {
        if (accountAgeDays(j.member) < cfg.minAccountAgeDays) {
          if (await kickYoung(j.member, 'Anti-raid : compte trop récent pendant un raid')) kicked++;
        }
      }

      const embed = securityEmbed(
        '🚨 هجوم محتمل على السيرفر (Raid)',
        `دخل **${recentJoins.length}** عضو في أقل من **${cfg.perSeconds}** ثواني.\n` +
        `🛡️ وضع الحماية مفعّل لمدة **${cfg.raidModeMinutes}** دقيقة: الحسابات الأقل من **${cfg.minAccountAgeDays}** أيام تُطرد تلقائياً.\n` +
        `👢 تم طرد **${kicked}** حساب جديد.`
      );
      await logSecurity(member.guild, embed);
      await dmOwner(client, { embeds: [embed] });
    }
  },
};
