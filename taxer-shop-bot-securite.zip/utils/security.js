const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config.json');

// ── Valeurs par défaut (utilisées si le bloc "security" manque dans config.json) ──
const DEFAULTS = {
  antiSpam:     { enabled: true, maxMessages: 6, perSeconds: 5, timeoutMinutes: 10 },
  antiMentions: { enabled: true, maxMentions: 5, timeoutMinutes: 30 },
  antiInvites:  { enabled: true },
  antiRaid:     { enabled: true, joins: 8, perSeconds: 10, raidModeMinutes: 10, minAccountAgeDays: 7 },
  antiNuke:     { enabled: true, autoRemoveRoles: true, channelDelete: 3, roleDelete: 3, massBan: 3, channelCreate: 5 },
};

function section(name) {
  return { ...DEFAULTS[name], ...(config.security?.[name] || {}) };
}

const OWNER_ID = config.security?.ownerId || '1113897921922994337';

// Les admins, le staff et l'owner ne sont jamais touchés par les protections
function isExempt(member) {
  if (!member) return false;
  if (member.id === OWNER_ID) return true;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  const roleIds = [config.tickets.staffRoleId, ...(config.tickets.adminRoleIds || [])];
  return roleIds.some(id => member.roles.cache.has(id));
}

// Envoie un embed dans le salon de logs
async function logSecurity(guild, embed) {
  const channelId = config.moderation.logChannelId || config.tickets.logChannelId;
  const channel = guild.channels.cache.get(channelId);
  if (channel) await channel.send({ embeds: [embed] }).catch(() => {});
}

// Envoie un message privé à l'owner
async function dmOwner(client, payload) {
  try {
    const owner = await client.users.fetch(OWNER_ID);
    await owner.send(payload);
  } catch (e) {
    console.error('DM owner error:', e.message);
  }
}

// Met un membre en timeout (retourne true si ça a marché)
async function timeoutMember(member, minutes, reason) {
  try {
    if (!member.moderatable) return false;
    await member.timeout(minutes * 60 * 1000, reason);
    return true;
  } catch (e) {
    console.error('Timeout error:', e.message);
    return false;
  }
}

// Message court qui disparaît tout seul
async function tempReply(channel, content, seconds = 6) {
  try {
    const msg = await channel.send(content);
    setTimeout(() => msg.delete().catch(() => {}), seconds * 1000);
  } catch {}
}

function securityEmbed(title, description, color = '#cc0000') {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp()
    .setFooter({ text: 'Taxer Shop • Security' });
}

module.exports = { section, OWNER_ID, isExempt, logSecurity, dmOwner, timeoutMember, tempReply, securityEmbed };
